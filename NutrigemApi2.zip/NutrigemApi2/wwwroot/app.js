﻿const apiBaseUrl = 'http://localhost:8080/api';

document.addEventListener('DOMContentLoaded', () => {
    // Login button
    const loginButton = document.getElementById('login-button');
    if (loginButton) {
        loginButton.addEventListener('click', login);
    }

    // Register button
    const registerButton = document.getElementById('register-button');
    if (registerButton) {
        registerButton.addEventListener('click', register);
    }

    // Check user on home page
    if (window.location.pathname.includes('home.html')) {
        const user = JSON.parse(localStorage.getItem('user'));
        if (user) {
            document.getElementById('user-name').textContent = user.fullName;
            displayBMI(user.userId); // Display BMI on home page
        } else {
            window.location.href = '/index.html';
        }
    }

    // Check admin dashboard
    if (window.location.pathname.includes('adminDashboard.html')) {
        const user = JSON.parse(localStorage.getItem('user'));
        if (!user || user.role !== 'Admin') {
            window.location.href = '/index.html';
        } else {
            document.getElementById('admin-info').innerText = `Admin ID: ${user.userId}`;
        }
    }

    // Check user dashboard
    if (window.location.pathname.includes('userDashboard.html')) {
        const user = JSON.parse(localStorage.getItem('user'));
        if (!user || user.role !== 'User') {
            window.location.href = '/index.html';
        }
    }
});

function register() {
    const userData = {
        fullName: document.getElementById('reg-fullname')?.value.trim(),
        email: document.getElementById('reg-email')?.value.trim(),
        password: document.getElementById('reg-password')?.value.trim(),
        age: parseInt(document.getElementById('reg-age')?.value),
        height: parseFloat(document.getElementById('reg-height')?.value),
        weight: parseFloat(document.getElementById('reg-weight')?.value),
        healthConditions: document.getElementById('reg-conditions')?.value.trim() || 'None',
        role: document.getElementById('reg-role')?.value || 'User'
    };

    const regResult = document.getElementById('reg-result');
    const registerButton = document.getElementById('register-button');

    // Validate inputs
    if (!userData.fullName || userData.fullName.length < 2) {
        regResult.innerHTML = '<p>Error: Full Name must be at least 2 characters long</p>';
        return;
    }
    if (!userData.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(userData.email)) {
        regResult.innerHTML = '<p>Error: Please enter a valid email address</p>';
        return;
    }
    if (!userData.password || userData.password.length < 6) {
        regResult.innerHTML = '<p>Error: Password must be at least 6 characters long</p>';
        return;
    }
    if (!userData.age || userData.age < 1 || userData.age > 120) {
        regResult.innerHTML = '<p>Error: Age must be between 1 and 120</p>';
        return;
    }
    if (!userData.height || userData.height < 50 || userData.height > 300) {
        regResult.innerHTML = '<p>Error: Height must be between 50 and 300 cm</p>';
        return;
    }
    if (!userData.weight || userData.weight < 20 || userData.weight > 500) {
        regResult.innerHTML = '<p>Error: Weight must be between 20 and 500 kg</p>';
        return;
    }

    // Show loading state
    registerButton.disabled = true;
    registerButton.textContent = 'Registering...';
    regResult.innerHTML = '';

    console.log('Registering user:', userData);

    fetch(`${apiBaseUrl}/user/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData)
    })
        .then(response => response.json())
        .then(data => {
            console.log('Registration response:', data);
            regResult.innerHTML = `<p>${data.message}</p>`;
            if (data.message === 'User registered successfully') {
                setTimeout(() => {
                    window.location.href = '/index.html';
                }, 1000);
            }
        })
        .catch(error => {
            console.error('Registration error:', error);
            regResult.innerHTML = `<p>Error: ${error.message}</p>`;
        })
        .finally(() => {
            // Reset button state
            registerButton.disabled = false;
            registerButton.textContent = 'Register';
        });
}

function login() {
    const email = document.getElementById('login-email')?.value.trim();
    const password = document.getElementById('login-password')?.value.trim();
    const loginResult = document.getElementById('login-result');
    const loginButton = document.getElementById('login-button');

    // Validate inputs
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        loginResult.innerHTML = '<p>Error: Please enter a valid email address</p>';
        return;
    }
    if (!password || password.length < 6) {
        loginResult.innerHTML = '<p>Error: Password must be at least 6 characters long</p>';
        return;
    }

    // Show loading state
    loginButton.disabled = true;
    loginButton.textContent = 'Logging in...';
    loginResult.innerHTML = '';

    console.log('Login attempt:', { email, password });

    fetch(`${apiBaseUrl}/user/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    })
        .then(response => {
            if (!response.ok) throw new Error('Invalid email or password');
            return response.json();
        })
        .then(data => {
            const userData = {
                fullName: data.fullName,
                role: data.role,
                userId: data.userId
            };
            console.log('Storing user data:', userData);
            localStorage.setItem('user', JSON.stringify(userData));
            if (data.role === 'Admin') {
                window.location.href = '/adminDashboard.html';
            } else {
                window.location.href = '/home.html';
            }
        })
        .catch(error => {
            loginResult.innerHTML = `<p>Error: ${error.message}</p>`;
        })
        .finally(() => {
            // Reset button state
            loginButton.disabled = false;
            loginButton.textContent = 'Login';
        });
}

function logout() {
    localStorage.removeItem('user');
    window.location.href = '/index.html';
}

// Navigate to diet plan page
function viewDietPlan() {
    window.location.href = '/dietPlan.html';
}

// Add or update a diet plan
function addDietPlan(userId, planType) {
    fetch(`${apiBaseUrl}/dietplan`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, planType })
    })
        .then(response => response.json())
        .then(data => {
            document.getElementById('diet-plan-error').innerHTML = `<p>${data.message}</p>`;
            if (data.message === 'Diet plan added successfully') {
                viewDietPlan(); // Refresh the diet plan display
            }
        })
        .catch(error => {
            document.getElementById('diet-plan-error').innerHTML = `<p>Error: ${error.message}</p>`;
        });
}

// Delete a diet plan
function deleteDietPlan(dietPlanId) {
    fetch(`${apiBaseUrl}/dietplan/${dietPlanId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
    })
        .then(response => response.json())
        .then(data => {
            document.getElementById('diet-plan-error').innerHTML = `<p>${data.message}</p>`;
            if (data.message === 'Diet plan deleted successfully') {
                viewDietPlan(); // Refresh the diet plan display
            }
        })
        .catch(error => {
            document.getElementById('diet-plan-error').innerHTML = `<p>Error: ${error.message}</p>`;
        });
}

// Navigate to water intake page
function logWaterIntake() {
    window.location.href = '/waterIntake.html';
}

// Log water intake
function logWaterIntake(userId, waterIntake) {
    fetch(`${apiBaseUrl}/waterintake`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, waterIntake })
    })
        .then(response => response.json())
        .then(data => {
            document.getElementById('water-intake-error').innerHTML = `<p>${data.message}</p>`;
            if (data.message === 'Water intake logged successfully') {
                viewWaterIntake(); // Refresh the water intake history
            }
        })
        .catch(error => {
            document.getElementById('water-intake-error').innerHTML = `<p>Error: ${error.message}</p>`;
        });
}

// View water intake history
function viewWaterIntake() {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user || !user.userId) return;

    fetch(`${apiBaseUrl}/waterintake/${user.userId}`)
        .then(response => {
            if (!response.ok) throw new Error('Failed to fetch water intake');
            return response.json();
        })
        .then(data => {
            const resultElement = document.getElementById('water-intake-result');
            if (data && data.length > 0) {
                let totalToday = 0;
                const today = new Date().toISOString().split('T')[0];
                const todayEntries = data.filter(entry => entry.date.startsWith(today));
                todayEntries.forEach(entry => totalToday += entry.amount);

                resultElement.innerHTML = `
                    <h3>Water Intake History</h3>
                    <p><strong>Today's Total:</strong> ${totalToday} ml</p>
                    <h4>Recent Entries:</h4>
                    <ul>
                        ${data.slice(0, 5).map(entry => `
                            <li>
                                ${entry.date}: ${entry.amount} ml 
                                <button onclick="deleteWaterIntake(${entry.waterIntakeId})">Delete</button>
                            </li>
                        `).join('')}
                    </ul>
                `;
            } else {
                resultElement.innerHTML = '<p>No water intake logged yet.</p>';
            }
        })
        .catch(error => {
            document.getElementById('water-intake-error').innerHTML = `<p>Error: ${error.message}</p>`;
        });
}

// Delete a water intake entry
function deleteWaterIntake(waterIntakeId) {
    fetch(`${apiBaseUrl}/waterintake/${waterIntakeId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
    })
        .then(response => response.json())
        .then(data => {
            document.getElementById('water-intake-error').innerHTML = `<p>${data.message}</p>`;
            if (data.message === 'Water intake deleted successfully') {
                viewWaterIntake(); // Refresh the water intake history
            }
        })
        .catch(error => {
            document.getElementById('water-intake-error').innerHTML = `<p>Error: ${error.message}</p>`;
        });
}

// Update height and weight
function updateHeightWeight(userId, height, weight) {
    fetch(`${apiBaseUrl}/user/update-height-weight`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, height, weight })
    })
        .then(response => response.json())
        .then(data => {
            document.getElementById('bmi-error').innerHTML = `<p>${data.message}</p>`;
            if (data.message === 'Height and weight updated successfully') {
                displayBMI(userId); // Refresh BMI display
            }
        })
        .catch(error => {
            document.getElementById('bmi-error').innerHTML = `<p>Error: ${error.message}</p>`;
        });
}

// Display BMI
function displayBMI(userId) {
    fetch(`${apiBaseUrl}/user/${userId}`)
        .then(response => {
            if (!response.ok) throw new Error('Failed to fetch user data');
            return response.json();
        })
        .then(data => {
            const bmiElement = document.getElementById('bmi-result');
            if (data && data.bmi) {
                bmiElement.innerHTML = `
                    <h3>Your BMI</h3>
                    <p><strong>BMI:</strong> ${data.bmi.toFixed(2)}</p>
                    <p><strong>Height:</strong> ${data.height} cm</p>
                    <p><strong>Weight:</strong> ${data.weight} kg</p>
                `;
            } else {
                bmiElement.innerHTML = '<p>BMI not available.</p>';
            }
        })
        .catch(error => {
            document.getElementById('bmi-error').innerHTML = `<p>Error: ${error.message}</p>`;
        });
}

// Delete user
function deleteUser(userId) {
    if (!confirm('Are you sure you want to delete this account? This action cannot be undone.')) {
        return;
    }

    fetch(`${apiBaseUrl}/user/${userId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
    })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            if (data.message === 'User deleted successfully') {
                logout(); // Log out and redirect to login page
            }
        })
        .catch(error => {
            alert(`Error: ${error.message}`);
        });
}

// View weight progress (mock implementation)
function viewWeightProgress() {
    const user = JSON.parse(localStorage.getItem('user'));
    const resultElement = document.getElementById('result');
    if (!resultElement) {
        console.error('result element not found');
        return;
    }
    if (!user) {
        resultElement.innerHTML = '<p>Error: User not logged in</p>';
        console.error('User not logged in');
        return;
    }
    resultElement.innerHTML = `
        <h3>Weight Progress</h3>
        <p><strong>Current Weight:</strong> ${user.weight} kg (from registration)</p>
        <p><strong>Starting Weight:</strong> ${user.weight} kg</p>
    `;
}